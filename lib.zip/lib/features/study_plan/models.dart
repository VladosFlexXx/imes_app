class StudyPlanItem {
  final int semester; // 1..N
  final String? code; // "Б1.В.01.01" и т.п.
  final String name;
  final String? controlForm; // "Экзамен", "Зачет", ...
  final String? totalHours; // строкой, чтобы UI мог trim()
  final String? lectures;
  final String? practice;

  const StudyPlanItem({
    required this.semester,
    required this.name,
    this.code,
    this.controlForm,
    this.totalHours,
    this.lectures,
    this.practice,
  });

  Map<String, dynamic> toJson() => {
        'semester': semester,
        'code': code,
        'name': name,
        'controlForm': controlForm,
        'totalHours': totalHours,
        'lectures': lectures,
        'practice': practice,
      };

  static StudyPlanItem fromJson(Map<String, dynamic> json) => StudyPlanItem(
        semester: (json['semester'] as num?)?.toInt() ?? 1,
        code: json['code'] as String?,
        name: (json['name'] as String?) ?? '',
        controlForm: json['controlForm'] as String?,
        totalHours: json['totalHours'] as String?,
        lectures: json['lectures'] as String?,
        practice: json['practice'] as String?,
      );
}
