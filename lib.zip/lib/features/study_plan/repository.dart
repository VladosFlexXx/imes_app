import 'package:flutter/foundation.dart';

import '../../core/cache/cached_repository.dart';
import '../../core/network/eios_client.dart';
import '../../core/logging/app_logger.dart';
import 'models.dart';
import 'parser.dart';

class StudyPlanRepository extends CachedRepository<List<StudyPlanItem>> {
  static final StudyPlanRepository instance = StudyPlanRepository._();

  StudyPlanRepository._()
      : super(
          key: 'study_plan_v1',
          initialData: const [],
          ttl: const Duration(hours: 6),
        );

  @override
  List<StudyPlanItem> readCache(Map<String, dynamic> json) {
    final raw = json['items'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map>()
        .map((e) => StudyPlanItem.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  @override
  Map<String, dynamic> writeCache(List<StudyPlanItem> data) {
    return {'items': data.map((e) => e.toJson()).toList()};
  }

  @override
  Future<List<StudyPlanItem>> fetchRemote() async {
    const url = 'https://eos.imes.su/local/cdo_education_plan/education_plan.php';
    try {
      final html = await EiosClient.instance.getHtml(url);
      return compute(StudyPlanParser.parse, html);
    } catch (e, st) {
      AppLogger.e('[StudyPlanRepository] refresh error', err: e, st: st);
      rethrow;
    }
  }
}
