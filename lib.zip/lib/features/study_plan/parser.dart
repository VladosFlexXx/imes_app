import 'package:html/parser.dart' as html_parser;
import 'package:html/dom.dart';

import 'models.dart';

class StudyPlanParser {
  /// Парсит education_plan.php.
  /// В HTML табы семестров выглядят как:
  /// <button onclick="openTab(event,'1716921')">Первый семестр</button>
  /// а контент:
  /// <div id="1716921" class="tabcontent"> ... <table>...</table>
  static List<StudyPlanItem> parse(String html) {
    final doc = html_parser.parse(html);

    // 1) находим все кнопки семестров
    final buttons = doc.querySelectorAll('button[onclick*="openTab"]');
    if (buttons.isEmpty) return const <StudyPlanItem>[];

    final result = <StudyPlanItem>[];

    for (final b in buttons) {
      final label = b.text.trim(); // "Первый семестр"
      final sem = _semesterFromLabel(label);
      final tabId = _tabIdFromOnClick(b.attributes['onclick'] ?? '');
      if (sem == null || tabId == null) continue;

      final tab = doc.querySelector('#$tabId');
      if (tab == null) continue;

      final table = tab.querySelector('table');
      if (table == null) continue;

      final rows = table.querySelectorAll('tr');
      if (rows.length <= 1) continue;

      // 2) определяем индексы колонок по заголовкам
      final headerCells = rows.first.querySelectorAll('th,td');
      final col = _detectColumns(headerCells);

      // 3) строки
      for (final tr in rows.skip(1)) {
        final cells = tr.querySelectorAll('td');
        if (cells.isEmpty) continue;

        final name = _cell(cells, col.name)?.trim();
        if (name == null || name.isEmpty) continue;

        result.add(
          StudyPlanItem(
            semester: sem,
            code: _cell(cells, col.code)?.trim(),
            name: name,
            controlForm: _cell(cells, col.controlForm)?.trim(),
            totalHours: _cell(cells, col.totalHours)?.trim(),
            lectures: _cell(cells, col.lectures)?.trim(),
            practice: _cell(cells, col.practice)?.trim(),
          ),
        );
      }
    }

    // стабильная сортировка: семестр, потом название
    result.sort((a, b) {
      final s = a.semester.compareTo(b.semester);
      if (s != 0) return s;
      return a.name.compareTo(b.name);
    });

    return result;
  }

  static int? _semesterFromLabel(String label) {
    final l = label.toLowerCase();
    // "Первый семестр", "Второй семестр", ... или у тебя могут быть "1 сем"
    if (RegExp(r'\b1\b').hasMatch(l) || l.contains('перв')) return 1;
    if (RegExp(r'\b2\b').hasMatch(l) || l.contains('втор')) return 2;
    if (RegExp(r'\b3\b').hasMatch(l) || l.contains('трет')) return 3;
    if (RegExp(r'\b4\b').hasMatch(l) || l.contains('четв')) return 4;
    if (RegExp(r'\b5\b').hasMatch(l) || l.contains('пят')) return 5;
    if (RegExp(r'\b6\b').hasMatch(l) || l.contains('шест')) return 6;
    if (RegExp(r'\b7\b').hasMatch(l) || l.contains('седь')) return 7;
    if (RegExp(r'\b8\b').hasMatch(l) || l.contains('вось')) return 8;
    return null;
  }

  static String? _tabIdFromOnClick(String onClick) {
    // openTab(event, '1716921')
    final m = RegExp(r"openTab\(\s*event\s*,\s*'([^']+)'\s*\)").firstMatch(onClick);
    return m?.group(1);
  }

  static String? _cell(List<Element> cells, int? idx) {
    if (idx == null) return null;
    if (idx < 0 || idx >= cells.length) return null;
    return cells[idx].text;
  }

  static _Cols _detectColumns(List<Element> headerCells) {
    int? find(String Function(String) test) {
      for (var i = 0; i < headerCells.length; i++) {
        final t = headerCells[i].text.trim().toLowerCase();
        if (test(t)) return i;
      }
      return null;
    }

    return _Cols(
      code: find((t) => t.contains('тип записи') || t.contains('код')),
      name: find((t) => t.contains('наименование') || t.contains('дисциплин')),
      controlForm: find((t) => t.contains('форма контроля') || t.contains('контрол')),
      totalHours: find((t) => t.contains('всего') && t.contains('час')),
      lectures: find((t) => t.contains('лекц')),
      practice: find((t) => t.contains('практ')),
    );
  }
}

class _Cols {
  final int? code;
  final int? name;
  final int? controlForm;
  final int? totalHours;
  final int? lectures;
  final int? practice;

  const _Cols({
    required this.code,
    required this.name,
    required this.controlForm,
    required this.totalHours,
    required this.lectures,
    required this.practice,
  });
}
