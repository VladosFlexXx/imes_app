class RecordbookRow {
  final String recordbookNumber; // "171692"
  final int semester; // 1..N
  final String discipline;
  final String? date;
  final String? controlType;
  final String? mark;
  final String? retake;
  final String? teacher;

  const RecordbookRow({
    required this.recordbookNumber,
    required this.semester,
    required this.discipline,
    this.date,
    this.controlType,
    this.mark,
    this.retake,
    this.teacher,
  });

  Map<String, dynamic> toJson() => {
        'recordbookNumber': recordbookNumber,
        'semester': semester,
        'discipline': discipline,
        'date': date,
        'controlType': controlType,
        'mark': mark,
        'retake': retake,
        'teacher': teacher,
      };

  static RecordbookRow fromJson(Map<String, dynamic> json) => RecordbookRow(
        recordbookNumber: (json['recordbookNumber'] as String?) ?? '',
        semester: (json['semester'] as num?)?.toInt() ?? 1,
        discipline: (json['discipline'] as String?) ?? '',
        date: json['date'] as String?,
        controlType: json['controlType'] as String?,
        mark: json['mark'] as String?,
        retake: json['retake'] as String?,
        teacher: json['teacher'] as String?,
      );
}
