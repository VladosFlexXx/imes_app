import 'package:flutter/foundation.dart';

import '../../core/cache/cached_repository.dart';
import '../../core/network/eios_client.dart';
import '../../core/logging/app_logger.dart';
import 'models.dart';
import 'parser.dart';

class RecordbookRepository extends CachedRepository<List<RecordbookRow>> {
  static final RecordbookRepository instance = RecordbookRepository._();

  RecordbookRepository._()
      : super(
          key: 'recordbook_v1',
          initialData: const [],
          ttl: const Duration(hours: 6),
        );

  @override
  List<RecordbookRow> readCache(Map<String, dynamic> json) {
    final raw = json['rows'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map>()
        .map((e) => RecordbookRow.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  @override
  Map<String, dynamic> writeCache(List<RecordbookRow> data) {
    return {'rows': data.map((e) => e.toJson()).toList()};
  }

  @override
  Future<List<RecordbookRow>> fetchRemote() async {
    const url = 'https://eos.imes.su/local/cdo_academic_progress/academic_progress.php';
    try {
      final html = await EiosClient.instance.getHtml(url);
      return compute(RecordbookParser.parse, html);
    } catch (e, st) {
      AppLogger.e('[RecordbookRepository] refresh error', err: e, st: st);
      rethrow;
    }
  }
}
