import 'package:html/parser.dart' as html_parser;
import 'package:html/dom.dart';

import 'models.dart';

class RecordbookParser {
  /// Парсит academic_progress.php.
  /// Там может быть несколько зачёток (вкладки gradebook-1, gradebook-2, ...)
  /// и внутри каждой — семестры (nav-2171692 и т.п.)
  static List<RecordbookRow> parse(String html) {
    final doc = html_parser.parse(html);

    // Ищем все "кнопки" зачёток в навигации (номер зачётки в тексте)
    final bookTabs = doc.querySelectorAll('a[data-toggle="pill"][href^="#nav-gradebook-"]');
    if (bookTabs.isEmpty) return const <RecordbookRow>[];

    final out = <RecordbookRow>[];

    for (final bookTab in bookTabs) {
      final href = (bookTab.attributes['href'] ?? '').trim(); // "#nav-gradebook-1"
      if (!href.startsWith('#')) continue;

      final bookNumber = bookTab.text.trim();
      final bookPaneId = href.substring(1);
      final bookPane = doc.querySelector('#$bookPaneId');
      if (bookPane == null) continue;

      // Внутри bookPane — табы семестров:
      final semTabs = bookPane.querySelectorAll('a.nav-link[href^="#nav-"]');
      if (semTabs.isEmpty) continue;

      for (final semTab in semTabs) {
        final semLabel = semTab.text.trim(); // "Первый семестр"
        final sem = _semesterFromLabel(semLabel);
        if (sem == null) continue;

        final semHref = (semTab.attributes['href'] ?? '').trim(); // "#nav-2171692"
        if (!semHref.startsWith('#')) continue;

        final semPaneId = semHref.substring(1);
        final semPane = bookPane.querySelector('#$semPaneId');
        if (semPane == null) continue;

        final table = semPane.querySelector('table');
        if (table == null) continue;

        final rows = table.querySelectorAll('tr');
        if (rows.length <= 1) continue;

        final headerCells = rows.first.querySelectorAll('th,td');
        final col = _detectColumns(headerCells);

        for (final tr in rows.skip(1)) {
          final cells = tr.querySelectorAll('td');
          if (cells.isEmpty) continue;

          final discipline = _cell(cells, col.discipline)?.trim();
          if (discipline == null || discipline.isEmpty) continue;

          out.add(
            RecordbookRow(
              recordbookNumber: bookNumber,
              semester: sem,
              discipline: discipline,
              date: _cell(cells, col.date)?.trim(),
              controlType: _cell(cells, col.controlType)?.trim(),
              mark: _cell(cells, col.mark)?.trim(),
              retake: _cell(cells, col.retake)?.trim(),
              teacher: _cell(cells, col.teacher)?.trim(),
            ),
          );
        }
      }
    }

    // сортируем: зачётка -> семестр -> дисциплина
    out.sort((a, b) {
      final r = a.recordbookNumber.compareTo(b.recordbookNumber);
      if (r != 0) return r;
      final s = a.semester.compareTo(b.semester);
      if (s != 0) return s;
      return a.discipline.compareTo(b.discipline);
    });

    return out;
  }

  static int? _semesterFromLabel(String label) {
    final l = label.toLowerCase();
    if (RegExp(r'\b1\b').hasMatch(l) || l.contains('перв')) return 1;
    if (RegExp(r'\b2\b').hasMatch(l) || l.contains('втор')) return 2;
    if (RegExp(r'\b3\b').hasMatch(l) || l.contains('трет')) return 3;
    if (RegExp(r'\b4\b').hasMatch(l) || l.contains('четв')) return 4;
    if (RegExp(r'\b5\b').hasMatch(l) || l.contains('пят')) return 5;
    if (RegExp(r'\b6\b').hasMatch(l) || l.contains('шест')) return 6;
    if (RegExp(r'\b7\b').hasMatch(l) || l.contains('седь')) return 7;
    if (RegExp(r'\b8\b').hasMatch(l) || l.contains('вось')) return 8;
    return null;
  }

  static String? _cell(List<Element> cells, int? idx) {
    if (idx == null) return null;
    if (idx < 0 || idx >= cells.length) return null;
    return cells[idx].text;
  }

  static _Cols _detectColumns(List<Element> headerCells) {
    int? find(bool Function(String) test) {
      for (var i = 0; i < headerCells.length; i++) {
        final t = headerCells[i].text.trim().toLowerCase();
        if (test(t)) return i;
      }
      return null;
    }

    return _Cols(
      discipline: find((t) => t.contains('дисциплин')),
      date: find((t) => t.contains('дата')),
      controlType: find((t) => t.contains('вид') || t.contains('контрол')),
      mark: find((t) => t.contains('отмет') || t.contains('оцен')),
      retake: find((t) => t.contains('пересдач')),
      teacher: find((t) => t.contains('преподав')),
    );
  }
}

class _Cols {
  final int? discipline;
  final int? date;
  final int? controlType;
  final int? mark;
  final int? retake;
  final int? teacher;

  const _Cols({
    required this.discipline,
    required this.date,
    required this.controlType,
    required this.mark,
    required this.retake,
    required this.teacher,
  });
}
