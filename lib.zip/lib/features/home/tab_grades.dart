import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../grades/models.dart';
import '../grades/repository.dart';
import '../schedule/schedule_repository.dart';

import '../recordbook/repository.dart';
import '../recordbook/models.dart';

import '../study_plan/repository.dart';
import '../study_plan/models.dart';

enum StudySection { disciplines, studyPlan, recordbook }

class GradesTab extends StatefulWidget {
  const GradesTab({super.key});

  @override
  State<GradesTab> createState() => _GradesTabState();
}

class _GradesTabState extends State<GradesTab> {
  final gradesRepo = GradesRepository.instance;
  final scheduleRepo = ScheduleRepository.instance;

  final planRepo = StudyPlanRepository.instance;
  final recordRepo = RecordbookRepository.instance;

  StudySection _section = StudySection.disciplines;

  String _query = '';

  // дисциплины
  int _cap = 50;

  // учебный план
  int _planSemester = 1;

  // зачётка
  String? _selectedGradebook;
  int _recordSemester = 1;

  static const _kGradesCapKey = 'grades_current_cap_v1';

  @override
  void initState() {
    super.initState();

    gradesRepo.initAndRefresh();
    scheduleRepo.initAndRefresh();

    planRepo.initAndRefresh();
    recordRepo.initAndRefresh();

    _loadCap();
  }

  Future<void> _loadCap() async {
    final prefs = await SharedPreferences.getInstance();
    final cap = prefs.getInt(_kGradesCapKey);
    if (cap != null && cap >= 0 && cap <= 200) {
      setState(() => _cap = cap);
    }
  }

  Future<void> _setCap(int v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kGradesCapKey, v);
    setState(() => _cap = v);
  }

  String _fmtTime(DateTime dt) =>
      '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';

  // =========================
  // Switch chips
  // =========================

  Widget _sectionSwitch() {
    Widget chip(StudySection s, String label, IconData icon) {
      final selected = _section == s;
      return ChoiceChip(
        label: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16),
            const SizedBox(width: 6),
            Text(label),
          ],
        ),
        selected: selected,
        onSelected: (_) => setState(() => _section = s),
      );
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Wrap(
        spacing: 8,
        children: [
          chip(StudySection.disciplines, 'Дисциплины', Icons.menu_book_outlined),
          chip(StudySection.studyPlan, 'Учебный план', Icons.view_list_outlined),
          chip(StudySection.recordbook, 'Зачётка', Icons.fact_check_outlined),
        ],
      ),
    );
  }

  // =========================
  // Helpers: disciplines filter
  // =========================

  String _normSubject(String s) {
    var x = s.toLowerCase().trim();

    // выкидываем популярные хвосты
    x = x.replaceAll(RegExp(r'\(.*?недел.*?\)'), ''); // (нечетная неделя)
    x = x.replaceAll(RegExp(r'\(ч\.\s*\d+\)'), ''); // (ч. 1)
    x = x.replaceAll(RegExp(r'\(часть.*?\)'), '');
    x = x.replaceAll(RegExp(r'\s+'), ' ').trim();

    return x;
  }

  Set<String> _scheduleSubjectsNorm() {
    final set = <String>{};
    for (final l in scheduleRepo.lessons) {
      final n = _normSubject(l.subject);
      if (n.isNotEmpty) set.add(n);
    }
    return set;
  }

  int? _extractPoints(GradeCourse c) {
    // пытаемся найти числовое поле в columns
    for (final e in c.columns.entries) {
      final k = e.key.toLowerCase();
      if (!(k.contains('балл') ||
          k.contains('рейтинг') ||
          k.contains('score') ||
          k.contains('points') ||
          k.contains('итого'))) {
        continue;
      }
      final raw = (e.value ?? '').toString();
      final m = RegExp(r'(\d{1,3})').firstMatch(raw);
      if (m != null) return int.tryParse(m.group(1)!);
    }
    return null;
  }

  List<GradeCourse> _applyQuery(List<GradeCourse> list) {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return list;
    return list.where((c) => c.courseName.toLowerCase().contains(q)).toList();
  }

  // =========================
  // Page: disciplines
  // =========================

  Future<void> _openCapDialog() async {
    final controller = TextEditingController(text: _cap.toString());
    final res = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Кап баллов для “текущих”'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            hintText: 'например 50 или 60',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () {
              final v = int.tryParse(controller.text.trim());
              if (v == null) return;
              Navigator.pop(ctx, v.clamp(0, 200));
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );

    if (res != null) {
      await _setCap(res);
    }
  }

  Widget _pageDisciplines() {
    final t = Theme.of(context).textTheme;

    final all = gradesRepo.courses;

    // нормализованные предметы из расписания
    final scheduleNorm = _scheduleSubjectsNorm();

    // 1) Текущие по твоему правилу: есть в расписании И баллы < cap
    bool isCurrent(GradeCourse c) {
      final inSchedule = scheduleNorm.contains(_normSubject(c.courseName));
      if (!inSchedule) return false;

      final pts = _extractPoints(c);
      if (pts == null) return true; // если баллы не нашли — считаем текущим
      return pts < _cap;
    }

    final current = all.where(isCurrent).toList();
    final others = all.where((c) => !isCurrent(c)).toList();

    // Защита от пустоты: если текущих 0 (из-за несовпадений названий) —
    // делаем мягче: просто "есть в расписании"
    if (current.isEmpty && scheduleNorm.isNotEmpty) {
      final softCurrent = all
          .where((c) => scheduleNorm.contains(_normSubject(c.courseName)))
          .toList();
      if (softCurrent.isNotEmpty) {
        current
          ..clear()
          ..addAll(softCurrent);
        others
          ..clear()
          ..addAll(all.where((c) => !softCurrent.contains(c)));
      }
    }

    final currentQ = _applyQuery(current);
    final othersQ = _applyQuery(others);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          onChanged: (v) => setState(() => _query = v),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'Поиск по дисциплинам',
          ),
        ),
        const SizedBox(height: 10),

        Row(
          children: [
            Text(
              'Текущие: кап $_cap',
              style: t.bodySmall?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 10),
            TextButton.icon(
              onPressed: _openCapDialog,
              icon: const Icon(Icons.tune, size: 18),
              label: const Text('Изменить'),
            ),
          ],
        ),
        const SizedBox(height: 6),

        if (!gradesRepo.loading && all.isEmpty) ...[
          const SizedBox(height: 80),
          Center(
            child: Text(
              'Нет данных по дисциплинам',
              style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
          ),
        ] else ...[
          if (currentQ.isNotEmpty) ...[
            Text('Текущие', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            for (final c in currentQ) _CourseCard(course: c, onTap: () {}),
            const SizedBox(height: 12),
          ],
          if (othersQ.isNotEmpty) ...[
            Text('Остальные', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            for (final c in othersQ) _CourseCard(course: c, onTap: () {}),
          ],
        ],

        const SizedBox(height: 60),
      ],
    );
  }

  // =========================
  // Page: study plan (семестры)
  // =========================

  List<int> _availablePlanSemesters(List<StudyPlanItem> items) {
    final s = items.map((e) => e.semester).where((x) => x > 0).toSet().toList();
    s.sort();
    return s.isEmpty ? [1, 2, 3, 4, 5, 6, 7, 8] : s;
  }

  Widget _semesterChips({
    required List<int> semesters,
    required int selected,
    required ValueChanged<int> onSelect,
  }) {
    String label(int sem) {
      const map = {
        1: '1',
        2: '2',
        3: '3',
        4: '4',
        5: '5',
        6: '6',
        7: '7',
        8: '8',
      };
      return '${map[sem] ?? sem} сем';
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Wrap(
        spacing: 8,
        children: [
          for (final sem in semesters)
            ChoiceChip(
              label: Text(label(sem)),
              selected: sem == selected,
              onSelected: (_) => onSelect(sem),
            ),
        ],
      ),
    );
  }

  Widget _pageStudyPlan() {
    final t = Theme.of(context).textTheme;

    final items = planRepo.items;
    final semesters = _availablePlanSemesters(items);
    if (!semesters.contains(_planSemester)) {
      _planSemester = semesters.first;
    }

    final list = items.where((e) => e.semester == _planSemester).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (planRepo.updatedAt != null || planRepo.lastError != null) ...[
          Row(
            children: [
              Icon(
                planRepo.lastError != null ? Icons.warning_amber_rounded : Icons.sync,
                size: 18,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  planRepo.lastError != null
                      ? 'Не удалось обновить · показаны сохранённые данные'
                      : 'Обновлено: ${_fmtTime(planRepo.updatedAt!)}',
                  style: t.bodySmall,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
        ],

        _semesterChips(
          semesters: semesters,
          selected: _planSemester,
          onSelect: (v) => setState(() => _planSemester = v),
        ),
        const SizedBox(height: 12),

        if (!planRepo.loading && items.isEmpty) ...[
          const SizedBox(height: 80),
          Center(
            child: Text(
              'Учебный план не найден в ЭИОС',
              textAlign: TextAlign.center,
              style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
          ),
        ] else ...[
          if (list.isEmpty && items.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 30),
              child: Center(
                child: Text(
                  'В этом семестре нет строк',
                  style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                ),
              ),
            )
          else
            for (final it in list) _StudyPlanCard(item: it),
        ],

        const SizedBox(height: 60),
      ],
    );
  }

  // =========================
  // Page: recordbook (несколько зачёток + семестры)
  // =========================

  List<String> _gradebooks(List<RecordbookRow> rows) {
    final s = rows.map((e) => e.gradebookNumber).where((x) => x.trim().isNotEmpty).toSet().toList();
    s.sort();
    return s;
  }

  List<int> _availableRecordSemesters(List<RecordbookRow> rows, String gradebook) {
    final s = rows
        .where((r) => r.gradebookNumber == gradebook)
        .map((e) => e.semester)
        .where((x) => x > 0)
        .toSet()
        .toList();
    s.sort();
    return s.isEmpty ? [1, 2, 3, 4, 5, 6, 7, 8] : s;
  }

  Widget _pageRecordbook() {
    final t = Theme.of(context).textTheme;

    final rows = recordRepo.rows;
    final gradebooks = _gradebooks(rows);

    if (_selectedGradebook == null && gradebooks.isNotEmpty) {
      _selectedGradebook = gradebooks.first;
    }

    final gb = _selectedGradebook;

    final semesters = gb == null ? <int>[1, 2, 3, 4, 5, 6, 7, 8] : _availableRecordSemesters(rows, gb);
    if (!semesters.contains(_recordSemester)) {
      _recordSemester = semesters.first;
    }

    final visible = (gb == null)
        ? const <RecordbookRow>[]
        : rows.where((r) => r.gradebookNumber == gb && r.semester == _recordSemester).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (recordRepo.updatedAt != null || recordRepo.lastError != null) ...[
          Row(
            children: [
              Icon(
                recordRepo.lastError != null ? Icons.warning_amber_rounded : Icons.sync,
                size: 18,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  recordRepo.lastError != null
                      ? 'Не удалось обновить · показаны сохранённые данные'
                      : 'Обновлено: ${_fmtTime(recordRepo.updatedAt!)}',
                  style: t.bodySmall,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
        ],

        if (gradebooks.length > 1) ...[
          DropdownButtonFormField<String>(
            value: _selectedGradebook,
            items: [
              for (final g in gradebooks)
                DropdownMenuItem(value: g, child: Text('Зачётка № $g')),
            ],
            onChanged: (v) => setState(() {
              _selectedGradebook = v;
            }),
            decoration: const InputDecoration(
              labelText: 'Выбор зачётки',
            ),
          ),
          const SizedBox(height: 12),
        ] else if (gradebooks.length == 1) ...[
          Text(
            'Зачётка № ${gradebooks.first}',
            style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 10),
        ],

        _semesterChips(
          semesters: semesters,
          selected: _recordSemester,
          onSelect: (v) => setState(() => _recordSemester = v),
        ),
        const SizedBox(height: 12),

        if (!recordRepo.loading && rows.isEmpty) ...[
          const SizedBox(height: 80),
          Center(
            child: Text(
              'Зачётная книжка не найдена в ЭИОС',
              textAlign: TextAlign.center,
              style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
          ),
        ] else ...[
          if (visible.isEmpty && rows.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 30),
              child: Center(
                child: Text(
                  'В этом семестре нет строк',
                  style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                ),
              ),
            )
          else
            for (final r in visible) _RecordbookCard(row: r),
        ],

        const SizedBox(height: 60),
      ],
    );
  }

  // =========================
  // refresh
  // =========================

  Future<void> _refreshCurrent() async {
    switch (_section) {
      case StudySection.disciplines:
        await gradesRepo.refresh(force: true);
        await scheduleRepo.refresh(force: true);
        return;
      case StudySection.studyPlan:
        await planRepo.refresh(force: true);
        return;
      case StudySection.recordbook:
        await recordRepo.refresh(force: true);
        return;
    }
  }

  bool _isLoadingCurrent() {
    switch (_section) {
      case StudySection.disciplines:
        return gradesRepo.loading || scheduleRepo.loading;
      case StudySection.studyPlan:
        return planRepo.loading;
      case StudySection.recordbook:
        return recordRepo.loading;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([gradesRepo, scheduleRepo, planRepo, recordRepo]),
      builder: (context, _) {
        final title = switch (_section) {
          StudySection.disciplines => 'Дисциплины',
          StudySection.studyPlan => 'Учебный план',
          StudySection.recordbook => 'Зачётная книжка',
        };

        return Scaffold(
          appBar: AppBar(
            title: Text(title),
            bottom: _isLoadingCurrent()
                ? const PreferredSize(
                    preferredSize: Size.fromHeight(3),
                    child: LinearProgressIndicator(minHeight: 3),
                  )
                : null,
            actions: [
              IconButton(
                tooltip: 'Обновить',
                onPressed: _isLoadingCurrent() ? null : () => _refreshCurrent(),
                icon: const Icon(Icons.refresh),
              ),
            ],
          ),
          body: RefreshIndicator(
            onRefresh: _refreshCurrent,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
              children: [
                _sectionSwitch(),
                const SizedBox(height: 12),

                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 180),
                  switchInCurve: Curves.easeOutCubic,
                  switchOutCurve: Curves.easeInCubic,
                  child: () {
                    switch (_section) {
                      case StudySection.disciplines:
                        return KeyedSubtree(
                          key: const ValueKey('disciplines'),
                          child: _pageDisciplines(),
                        );
                      case StudySection.studyPlan:
                        return KeyedSubtree(
                          key: const ValueKey('study_plan'),
                          child: _pageStudyPlan(),
                        );
                      case StudySection.recordbook:
                        return KeyedSubtree(
                          key: const ValueKey('recordbook'),
                          child: _pageRecordbook(),
                        );
                    }
                  }(),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// =========================
// Cards
// =========================

class _CourseCard extends StatelessWidget {
  final GradeCourse course;
  final VoidCallback onTap;

  const _CourseCard({required this.course, required this.onTap});

  bool _hasGrade() {
    final g = course.grade;
    return g != null && g.trim().isNotEmpty && g.trim() != '—' && g.trim() != '-';
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;

    final any = _hasGrade();
    final grade = course.grade?.trim();

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      child: SizedBox(
        width: double.infinity,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    course.courseName,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 10),
                if (any && grade != null)
                  _Badge(text: grade)
                else
                  Text('—', style: t.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                const SizedBox(width: 6),
                Icon(Icons.chevron_right, color: cs.onSurface.withOpacity(0.6)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StudyPlanCard extends StatelessWidget {
  final StudyPlanItem item;

  const _StudyPlanCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;

    final chips = <Widget>[];

    if ((item.controlForm ?? '').trim().isNotEmpty) {
      chips.add(_Chip(text: item.controlForm!.trim()));
    }
    if ((item.totalHours ?? '').trim().isNotEmpty) {
      chips.add(_Chip(text: '${item.totalHours!.trim()} ч'));
    }
    if ((item.lectures ?? '').trim().isNotEmpty && item.lectures!.trim() != '0') {
      chips.add(_Chip(text: 'Лек: ${item.lectures!.trim()}'));
    }
    if ((item.practice ?? '').trim().isNotEmpty && item.practice!.trim() != '0') {
      chips.add(_Chip(text: 'Практ: ${item.practice!.trim()}'));
    }

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      child: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.discipline,
                style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              if (chips.isNotEmpty) Wrap(spacing: 8, runSpacing: 8, children: chips),
              if (item.recordType.trim().isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  item.recordType.trim(),
                  style: t.bodySmall?.copyWith(color: cs.onSurface.withOpacity(0.7)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _RecordbookCard extends StatelessWidget {
  final RecordbookRow row;

  const _RecordbookCard({required this.row});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;

    final chips = <Widget>[];
    if ((row.controlType ?? '').trim().isNotEmpty) chips.add(_Chip(text: row.controlType!.trim()));
    if ((row.date ?? '').trim().isNotEmpty) chips.add(_Chip(text: row.date!.trim()));
    if ((row.mark ?? '').trim().isNotEmpty) chips.add(_Chip(text: row.mark!.trim()));
    if ((row.retake ?? '').trim().isNotEmpty) chips.add(_Chip(text: 'Пересдача: ${row.retake!.trim()}'));

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      child: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                row.discipline,
                style: t.titleMedium?.copyWith(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              if (chips.isNotEmpty) Wrap(spacing: 8, runSpacing: 8, children: chips),
              if ((row.teacher ?? '').trim().isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  row.teacher!.trim(),
                  style: t.bodySmall?.copyWith(color: cs.onSurface.withOpacity(0.7)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// =========================
// UI helpers
// =========================

class _Badge extends StatelessWidget {
  final String text;
  const _Badge({required this.text});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: cs.primaryContainer,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cs.onPrimaryContainer.withOpacity(0.12)),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w900,
              color: cs.onPrimaryContainer,
              height: 1.0,
            ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String text;
  const _Chip({required this.text});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        color: cs.surfaceVariant.withOpacity(0.35),
        border: Border.all(color: cs.outlineVariant.withOpacity(0.35)),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800),
      ),
    );
  }
}
