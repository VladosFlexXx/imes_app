enum WeekParity {
  odd,
  even,
  unknown,
}
